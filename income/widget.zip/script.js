'use strict';

define(
    [
        'moment',
        'jquery',
        'underscore',
        'lib/components/base/modal',
        './js/Utils.js',
        './libs/sortable-1.6.0/Sortable.min.js',
        'require',
        'json!./manifest.json',
        './libs/fileupload-9.23.0/jquery.iframe-transport.js',
        './libs/fileupload-9.23.0/jquery.fileupload.js',
    ],
    function (moment, $, _, Modal, Utils, Sortable, require, manifest) {
        let giftData = {};

        (function () {
            window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
                window.webkitRequestAnimationFrame || window.msRequestAnimationFrame || (callback => callback());
        })();

        return function () {
            const self             = this;
            const eventNamespace   = '.getdocget8';
            const clickNs          = `click${eventNamespace}`;
            const hoverNs          = `mouseenter${eventNamespace} mouseleave${eventNamespace}`;
            const changeNs         = `change${eventNamespace}`;
            const inputNs          = `input${eventNamespace}`;
            const keydownNs        = `keydown${eventNamespace}`;
            const controlsChangeNs = `controls:change${eventNamespace}`;
            const multisuggestNs   = `multisuggest:item:choose${eventNamespace}`;
            const focusoutNs       = `focusout${eventNamespace}`;
            const widgetInstalled  = `widget:${manifest.widget.code}:installed`;
            const widgetRemoved    = `widget:${manifest.widget.code}:removed`;

            const MAX_UPLOAD_FILE_SIZE = 5242880;
            const EMAIL_REGEXP         = /^(([^<>()\[\].,;:\s@"]+(\.[^<>()\[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/i;

            this.widgetCode = 'amo_getdoc';
            this.debugMode  = false;
            this.utils      = new Utils(self);
            this.version    = manifest.widget.version;

            let managersWithGroup;
            let $rightWidget;
            let placeholders;
            let userRights;
            let uploadGroupId;
            let balanceNotifySettings;

            const SUPPORTED_AREA = {
                advancedSettings : 'widget.advanced_settings',
                settings         : 'settings.widgets',
                lcard            : 'leads.card',
            };

            let currentArea;

            let buttonDisable = false;

            Object.defineProperties(self, {
                'cssPath'       : {
                    get() {
                        const cssPath = self.params.path + '/css/';

                        Object.defineProperty(this, 'cssPath', {
                            value : cssPath,
                        });

                        return cssPath;
                    },
                    configurable : true,
                },
                'baseTemplates' : {
                    get() {
                        const templatePath = self.params.path.substr(1) + '/templates/';

                        Object.defineProperty(this, 'baseTemplates', {
                            value : templatePath,
                        });

                        return templatePath;
                    },
                    configurable : true,
                },
            });

            this.buttonWithLoading = function (callback) {
                return async function (e) {
                    e.stopPropagation();
                    e.preventDefault();

                    const $button        = $(this);
                    const alreadyLoading = $button.data('get8-loading');
                    if (alreadyLoading) {
                        return;
                    }

                    $button.data('get8-loading', true);

                    const callbackIsPromise = typeof callback === 'object' && 'then' in callback;
                    const promisedCallback  = callbackIsPromise ? callback : Promise.resolve(callback.apply(this, e));

                    await promisedCallback;

                    $button.data('get8-loading', false);
                };
            };

            this.timerCallback = function (seconds, onTick, onFinish = () => {
            }) {
                if (seconds < 1) {
                    onFinish();

                    return;
                }

                let restSeconds = seconds;

                onTick(restSeconds);
                const timerId = setInterval(() => {
                    restSeconds -= 1;
                    onTick(restSeconds);
                    if (restSeconds <= 0) {
                        clearInterval(timerId);
                        onFinish();
                    }
                }, 1000);
            };

            this.createGiftModal = async function () {
                return self.utils.createModal('gift', giftData, {
                    id : 'get8_getdoc_gift_modal',
                }).then(({$modalBody, modal}) => {
                    const $phone           = $modalBody.find('input[name=phone]');
                    const $site            = $modalBody.find('input[name=site]');
                    const $code            = $modalBody.find('input[name=code]');
                    const $blockNotify     = $modalBody.find('.error-notify');
                    const removeErrorClass = function ($el) {
                        $el.removeClass('get8-error');
                    };
                    const errorNotify      = (function () {
                        let lastTimerId = null;
                        return function (errorText, timeout = 5000) {
                            if (lastTimerId) {
                                clearTimeout(lastTimerId);
                                lastTimerId = null;
                            }

                            $blockNotify.text(errorText);
                            lastTimerId = setTimeout(() => {
                                $blockNotify.text('');
                                lastTimerId = null;
                            }, timeout);
                        };
                    })();

                    $modalBody
                        .on('click', '.get-code', async function () {
                            const $button    = $(this);
                            const isLoading  = $button.data('loading');
                            const isDisabled = $button.hasClass('button-input-disabled');

                            if (isLoading || isDisabled) {
                                return false;
                            }

                            $button.trigger('button:load:start');

                            const phone = $phone.val().trim() || null;
                            try {
                                await self.utils.get(self.utils.getUrl('settings', 'get_verification_code'), {
                                    phone,
                                });

                                $button
                                    .trigger('button:load:stop')
                                    .trigger('button:save:disable');

                                const $buttonInnerText = $button.find('.button-input-inner__text');
                                const buttonText       = $buttonInnerText.text();
                                self.timerCallback(
                                    60,
                                    restSeconds => {
                                        const normalizedSeconds = restSeconds >= 10
                                            ? restSeconds
                                            : '0' + restSeconds;
                                        $buttonInnerText.text(`00:${normalizedSeconds}`);
                                    },
                                    () => {
                                        $button.trigger('button:save:enable');
                                        $buttonInnerText.text(buttonText);
                                    },
                                );
                            } catch (e) {
                                if ('error' in e) {
                                    errorNotify(e.error);
                                }

                                $button
                                    .trigger('button:load:error')
                                    .trigger('button:save:enable');
                            }
                        })
                        .on('click', '.deny', function () {
                            self.utils.post(self.utils.getUrl('settings', 'deny_gift'));
                        })
                        .on('click', '.delay', function () {
                            modal.destroy();
                        })
                        .on('click', '.agree', async function () {
                            const $button      = $(this);
                            const site         = $site.val() || '';
                            const siteTrimmed  = site.trim() || null;
                            const phone        = $phone.val() || '';
                            const phoneTrimmed = phone.trim() || null;
                            const code         = $code.val() || '';
                            const codeTrimmed  = code.trim() || null;

                            if (!phone && !site) {
                                $phone
                                    .addClass('get8-error')
                                    .one('focus', () => {
                                        removeErrorClass($site);
                                        removeErrorClass($phone);
                                    });
                                $site
                                    .addClass('get8-error')
                                    .one('focus', () => {
                                        removeErrorClass($site);
                                        removeErrorClass($phone);
                                    });
                                $button.trigger('button:save:error');

                                return;
                            }

                            if (phone && !code) {
                                $code
                                    .addClass('get8-error')
                                    .one('focus', () => {
                                        removeErrorClass($code);
                                    });
                                $button.trigger('button:save:error');

                                return;
                            }

                            $button.trigger('button:load:start');
                            try {
                                const response = await self.utils.post(
                                    self.utils.getUrl('settings', 'gift'),
                                    {
                                        phone : phoneTrimmed,
                                        site  : siteTrimmed,
                                        code  : codeTrimmed,
                                    },
                                );
                                $button.trigger('button:load:stop');

                                giftData = {...giftData, ...response};
                                modal.destroy();

                                if (giftData.gift_received) {
                                    $('#tab-control').find('.get-generations').remove();
                                }
                            } catch (e) {
                                if ('error' in e) {
                                    errorNotify(e.error);
                                }

                                $button.trigger('button:save:error');
                            }
                        })
                        .trigger('modal:centrify')
                        .trigger('modal:loaded');
                });
            };

            this.openPreviewIframe = function openPreviewIframe(documentUrl) {
                return self.utils.createModal(null, null, {
                    add_class : 'getdoc-document-preview',
                    html      : `<iframe src="https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(
                        decodeURIComponent(documentUrl))}" frameborder='0'></iframe>`,
                }).then(({$modalBody}) => {
                    $modalBody.find('iframe')
                        .on('load', function () {
                            $modalBody.trigger('modal:centrify').trigger('modal:loaded');
                        });
                });
            };

            this.getSort = function getSort() {
                if (!self.$templateTable) {
                    self.$templateTable = $('.templates-table', '#work_area');
                }

                let sort = [];

                const $templatesGroup = self.$templateTable.find('.templates-group');
                if (!$templatesGroup.length) {
                    return sort;
                }

                $templatesGroup.each(function () {
                    const $this     = $(this);
                    const fileNames = [];

                    $this.find('.getdoc-template:not(.templates-empty)')
                        .each(function () {
                            fileNames.push($(this).find('.name').text().trim());
                        });
                    sort.push({
                        files : fileNames,
                        name  : $this.find('.group-header .name').text().trim(),
                    });
                });

                return sort;
            };

            this.saveSort = _.debounce(function saveSort() {
                const sort = self.getSort();

                return self.utils.post(self.utils.getUrl('sort', 'set'), {sort});
            }, 1000);

            this.saveDocumentGenerations = async function saveDocumentGenerations() {
                if (buttonDisable){
                    return;
                }

                buttonDisable = true;
                let $template = $(this).parents('.getdoc-template');
                let $generationNumber = $(this).prev();
                
                try {
                    await self.utils.post(self.utils.getUrl('templates', 'change_generation_number'), {
                        filename : $template.data('fileName'),
                        number   : $generationNumber[0].value,
                    });

                    new Modal({}).showSuccess('Количество генераций сохранено!', null, 3000);
                    buttonDisable = false;
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                    buttonDisable = false;
                }
            };

            this.initSortableGroups = function initSortableGroups(mainElement) {
                return Sortable.create(mainElement, {
                    group       : {
                        name : 'template-groups',
                        pull : true,
                        put  : true,
                    },
                    filter      : '.getdoc-template, .templates-group:first-child',
                    draggable   : '.templates-group',
                    handle      : '.templates-table',
                    ghostClass  : 'sortable-group-ghost',
                    chosenClass : 'sortable-group-chosen',
                    dragClass   : 'sortable-group-drag',
                    onEnd() {
                        self.saveSort();
                    },
                });
            };

            this.initSortableFiles = function initSortableFiles(templatesNodes) {
                templatesNodes.forEach((templates) => {
                    Sortable.create(templates, {
                        group         : 'getdoc-templates',
                        draggable     : '.getdoc-template',
                        handle        : '.templates',
                        ghostClass    : 'sortable-template-ghost',
                        chosenClass   : 'sortable-template-chosen',
                        dragClass     : 'sortable-template-drag',
                        fallbackClass : 'sortable-template-fallback',
                        filter        : 'ul.more-settings.show',
                        onEnd() {
                            self.saveSort();
                        },
                    });
                });
            };

            this.initFileUpload = function initFileUpload($fileUpload) {
                $fileUpload.fileupload({
                    url               : self.utils.getUrl('templates', 'add'),
                    type              : 'POST',
                    dataType          : 'json',
                    singleFileUploads : false,
                    acceptFileTypes   : /(.|\/)(docx)$/i,
                    maxFileSize       : MAX_UPLOAD_FILE_SIZE,
                    add(e, data) {
                        self.advancedSettingsLoader(true);

                        if (data.autoUpload || (data.autoUpload !== false && $(this).fileupload('option', 'autoUpload'))
                        ) {
                            data.process().done(function () {
                                data.submit();
                            });
                        }
                    },
                    done(e, data) {
                        if (data.result.error) {
                            self.utils.error(data.result.error, self.i18n('error.error'));

                            return;
                        }

                        $.each(data.result.data, function (index, template) {
                            if (typeof template.error !== 'undefined') {
                                self.utils.error(template.error, self.i18n('error.error'));

                                return;
                            }

                            self.appendTemplate(template, uploadGroupId);
                        });
                    },
                    fail() {
                        self.utils.error(self.i18n('error.download_template'), self.i18n('error.error'));
                    },
                    always() {
                        self.advancedSettingsLoader(false);
                    },
                });
            };

            this.appendTemplate = async function appendTemplate(file, uploadGroupId) {
                if (!this.templateTemplate) {
                    this.templateTemplate = await self.utils.getTemplatePromise(
                        'advanced_settings/tab_templates/template');
                }

                const $newTemplate              = $(this.templateTemplate.render({
                    file,
                })).hide();
                const $previousRenderedTemplate = $(
                    `.getdoc-template[data-file-name="${file.name}"]`,
                    '#tab-templates',
                );

                if ($previousRenderedTemplate.length) {
                    if ($previousRenderedTemplate.parents('.templates-group').index() === uploadGroupId) {
                        window.requestAnimationFrame(function () {
                            $previousRenderedTemplate.fadeOut('slow', function () {
                                $(this).replaceWith($newTemplate);
                                $newTemplate.fadeIn('slow');
                            });
                        });
                    } else {
                        window.requestAnimationFrame(function () {
                            $previousRenderedTemplate.fadeOut('slow', function () {
                                $(this).remove();
                                $newTemplate
                                    .appendTo($($('.templates-group', '#tab-templates')[uploadGroupId])
                                        .find('.templates'))
                                    .fadeIn('slow');
                                self.saveSort();
                            });
                        });
                    }
                } else {
                    window.requestAnimationFrame(function () {
                        $newTemplate
                            .appendTo($($('.templates-group', '#tab-templates')[uploadGroupId]).find('.templates'))
                            .slideDown('slow');
                    });

                    self.saveSort();
                }
            };

            this.getCurrentLeadId = function getCurrentLeadId() {
                if (currentArea === SUPPORTED_AREA.lcard) {
                    return parseInt(AMOCRM.data.current_card.id);
                }

                return null;
            };

            this.getContactsByCurrentLead = function getContactsByCurrentLead() {
                let contacts = [];
                if (currentArea === SUPPORTED_AREA.lcard) {
                    AMOCRM.data.current_card.linked_forms.form_models.models.forEach(function (item) {
                        if (item.attributes.ELEMENT_TYPE == 1
                            && item.attributes.ID && item.attributes['contact[FN]']
                        ) {
                            contacts.push({
                                id   : parseInt(item.attributes.ID),
                                name : item.attributes['contact[FN]'],
                            });
                        }
                    });
                }

                return contacts;
            };

            this.downloadFile = function downloadFile(documentUrl) {
                $('<iframe/>').attr({
                    src   : decodeURIComponent(documentUrl).replace(/#/g, '%23').replace(/\s/g, '%20'),
                    style : 'visibility:hidden;display:none',
                })
                    .appendTo('body');
            };

            this.appendDocument = async function appendDocument(document) {
                if (!this.documentTemplate) {
                    this.documentTemplate = await self.utils.getTemplatePromise('document');
                }

                if (!this.$documents) {
                    this.$documents = $('.documents-block', self.utils.id());
                }

                window.requestAnimationFrame(() => {
                    this.$documents.append(this.documentTemplate.render({
                        document,
                        rights   : userRights,
                        timezone : AMOCRM.constant('account').timezone,
                    }));
                });
            };

            this.generateDocumentByLead = async function generateDocumentByLead(
                entity,
                leadId,
                contactId,
                filename,
                extension,
            ) {
                self.loader($rightWidget.find('.widget-wrap'), true);
                const user = AMOCRM.constant('user');
                try {
                    const document = await self.utils.post(self.utils.getUrl('templates', 'generate'), {
                        'entity'     : entity,
                        'lead_id'    : leadId,
                        'contact_id' : contactId,
                        'filename'   : filename,
                        'extension'  : extension,
                        'user_name'  : user.name,
                        'user_id'    : user.id,
                    });

                    self.downloadFile(document.url);
                    self.appendDocument(document);
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                }

                self.loader($rightWidget.find('.widget-wrap'), false);
            };

            this.generatePreview = async function generatePreview(entity, leadId, contactId, filename) {
                self.utils.getTemplatePromise('show-preview');
                self.loader($rightWidget.find('.widget-wrap'), true);

                let templatePreview;
                try {
                    templatePreview = await self.utils.getJson(self.utils.getUrl('templates', 'preview'), {
                        lead_id    : leadId,
                        contact_id : contactId,
                        filename   : filename,
                        user_id    : AMOCRM.constant('user').id,
                    });

                    const modalData    = {
                        data : encodeURI(templatePreview),
                    };
                    const modalOptions = {
                        id       : self.utils.id('preview', false),
                        addClass : 'modal-preview',
                    };

                    const modalResponse = (await self.utils.createModal('show-preview', modalData, modalOptions));

                    modalResponse
                        .$modalBody
                        .trigger('modal:centrify')
                        .trigger('modal:loaded')
                        .on(clickNs, '.show-preview-generate', function () {
                            self.generateDocumentByLead(entity, leadId, contactId, filename, this.dataset.ext);
                            modalResponse.modal.destroy();
                        })
                        .on(clickNs, '.show-preview-cancel', function () {
                            modalResponse.modal.destroy();
                        });
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));

                }

                self.loader($rightWidget.find('.widget-wrap'), false);
            };

            this.loader = async function loader($block, show = true) {
                if (!this.loaderTemplate) {
                    this.loaderTemplate = await self.utils.getTemplatePromise('loader');
                }

                if (show) {
                    if (!$block.find('.getdoc-overlay-loader').length) {
                        $block.append(this.loaderTemplate.render());
                    }
                } else {
                    $block.find('.getdoc-overlay-loader').remove();
                }
            };

            this.prepareSort = function prepareSort(sort = [], responseFiles = []) {
                if (!sort.length) {
                    sort.push({
                        name  : self.i18n('templates.advanced_settings.tab_templates.tab.templates_table.name'),
                        files : [],
                        sort  : 0,
                    });
                }

                let sortTmp = JSON.parse(JSON.stringify(sort));
                $.each(sortTmp, function (index, group) {
                    let filesTmp = [];
                    group.files  = typeof group.files !== 'undefined' && Array.isArray(group.files) ? group.files : [];
                    group.files  = group.files || [];
                    $.each(group.files, function (index, file) {
                        let responseFile = $.grep(responseFiles, function (dataFile) {
                            return dataFile.name === file;
                        });

                        if (!responseFile.length) {
                            return;
                        }

                        filesTmp.push(responseFile[0]);
                        responseFiles.splice(responseFiles.indexOf(responseFile[0]), 1);

                        if (typeof responseFile.error !== 'undefined') {
                            AMOCRM.notifications.add_error({
                                header : 'GetDoc: ' + self.i18n('error.error'),
                                text   : file.error,
                                date   : Math.ceil(Date.now() / 1000),
                            });
                        }
                    });

                    group.files = filesTmp;
                });

                if (responseFiles.length) {
                    sortTmp[0].files = sortTmp[0].files.concat(responseFiles);
                }

                return sortTmp;
            };

            this.getSettingsForRightWidget = function getSettingsForRightWidget() {
                return self.utils.get(self.utils.getUrl('settings', 'get_widget_settings'), {
                    'entity_id' : self.getCurrentLeadId(),
                    'entity'    : AMOCRM.data.current_entity,
                });
            };

            this.groupDelete = async function groupDelete() {
                const $button        = $(this);
                const $templateGroup = $button.closest('.templates-group');
                const $templates     = $templateGroup.find('.getdoc-template:not(.templates-empty)');

                $button.trigger('button:load:start');

                if (!$templates.length) {
                    self.groupConfirmRemove($templateGroup, $templates);

                    return false;
                }

                const userDecision = await self.openConfirmationModal(
                    'group-remove',
                    self.i18n('group_confirm_delete'),
                );

                if (userDecision === true) {
                    self.groupConfirmRemove($templateGroup, $templates);
                }

                return false;
            };

            this.groupConfirmRemove = function groupConfirmRemove($group, $templates) {
                let $mainGroup = $('#work_area')
                    .find('.templates-group')
                    .first()
                    .find('.templates');

                $templates
                    .hide()
                    .appendTo($mainGroup)
                    .slideDown();

                $group.slideUp('normal', function () {
                    $group.remove();
                });

                self.saveSort();
            };

            this.toggleTemplates = function toggleTemplates() {
                const $this = $(this);
                requestAnimationFrame(() => {
                    $this.next().toggle();

                    const $arrow = $this.find('.template-title-arrow');
                    if ($arrow.length) {
                        $arrow
                            .children('span')
                            .toggleClass('icon-arrow-down')
                            .toggleClass('icon-arrow-top');
                    }
                });

                return false;
            };

            this.renameGroup = function renameGroup() {
                const $groupName = $(this).parents('.templates-group').find('.group-header').find('.name');

                $groupName
                    .attr('contenteditable', true)
                    .data('oldName', $groupName.text().trim())
                    .focus();

                return false;
            };

            this.renameTemplate = function renameTemplate() {
                const templateName = $(this).parents('.getdoc-template').find('.name');

                templateName.attr('contenteditable', true)
                    .data('oldName', templateName.text().trim())
                    .focus();

                return false;
            };

            this.changeInTheNumberOfGenerations = function changeInTheNumberOfGenerations() {
                const templateGenerations = $(this);

                templateGenerations.attr('contenteditable', true)
                    .data('oldName', templateGenerations.text().trim())
                    .focus();

                return false;
            };

            this.blurRenameGroup = function blurRenameGroup() {
                const $groupName = $(this);

                $groupName.attr('contenteditable', false);

                if (!$groupName.text()) {
                    $groupName.text($groupName.data('oldName'));

                    return true;
                }

                self.saveSort();

                return false;
            };

            this.blurRenameTemplate = async function blurRenameTemplate() {
                const $this                     = $(this);
                const $getdocTemplate           = $this.parents('.getdoc-template');
                const oldTemplateName           = $this.data('oldName');
                const newTamplateName           = $this.text().trim();
                const newTamplateNameTrimmedDot = newTamplateName.replace(/^\.+/, '');

                $this.attr('contenteditable', false);

                if (!newTamplateNameTrimmedDot) {
                    $this.text(oldTemplateName);

                    return;
                }

                if (oldTemplateName === newTamplateNameTrimmedDot) {
                    $this.text(oldTemplateName);

                    return;
                }

                try {
                    let response = await self.utils.post(self.utils.getUrl('templates', 'rename'), {
                        filename_old : oldTemplateName,
                        filename_new : self.removeDocxExtension(newTamplateNameTrimmedDot),
                        visible      : $getdocTemplate.data('visible'),
                        sort         : self.getSort(),
                    });

                    $this.text(response.name);
                    $getdocTemplate.data({fileName : response.name, fileUrl : response.url});
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                    $this.text(oldTemplateName);
                }
            };

            this.onPressEnter = function onPressEnter(e) {
                if (e.which !== 13) {
                    return true;
                }

                $(this).focusout();

                return false;
            };

            this.removeDocxExtension = function removeDocxExtension(filenameWithExt) {
                if (!filenameWithExt.endsWith('.docx')) {
                    return filenameWithExt;
                }

                let filenameWithoutExt = filenameWithExt.split('.');
                filenameWithoutExt.pop();

                return filenameWithoutExt.join('.');
            };

            this.uploadTemplatesClick = function uploadTemplatesClick() {
                uploadGroupId = $(this).parents('.templates-group').index();
                $('#upload-templates').trigger(AMOCRM.click_event);

                return false;
            };

            this.downloadTemplate = function downloadTemplate() {
                let fileUrl = $(this).parents('.getdoc-template').data('fileUrl');

                self.downloadFile(fileUrl);

                return false;
            };

            this.toggleMoreInfo = function toggleMoreInfo() {
                const $getdocTemplate = $(this).parents('.getdoc-template');
                const $button = $(this).parents('.getdoc-template').find('button.getdoc_save_document_generations');
                
                $button.attr('disabled') === undefined ? $button.prop('disabled', true) : $button.prop('disabled', false);
                $getdocTemplate.find('.toggle-more-info').toggleClass('icon-more-rotate');
                $getdocTemplate.find('.more-settings').toggleClass('show');

                return true;
            };

            this.previewTemplate = function previewTemplate() {
                self.openPreviewIframe($(this).parents('.getdoc-template').data('fileUrl'));

                return false;
            };

            this.deleteTemplate = async function removeTemplate() {
                let $template = $(this).parents('.getdoc-template');

                try {
                    await self.utils.post(self.utils.getUrl('templates', 'remove'), {
                        filename : $template.data('fileName'),
                        sort     : self.getSort(),
                        visible  : $template.data('visible'),
                    });

                    $template.slideUp('normal', function () {
                        $(this).remove();
                    });
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                }

                return false;
            };

            this.openModalChooseContact = async function (contacts) {
                return new Promise(function (resolve, reject) {
                    const modalData    = {
                        contacts,
                    };
                    const modalOptions = {
                        id : self.utils.id('choose-contact', false),
                        destroy() {
                            reject();
                        },
                    };
                    self.utils.createModal('choose-contact', modalData, modalOptions)
                        .then(({$modalBody, modal}) => {
                            $modalBody
                                .on('click', '.contact-choose-button', function () {
                                    resolve(this.dataset.id);
                                    modal.destroy();
                                })
                                .trigger('modal:centrify')
                                .trigger('modal:loaded');
                        })
                        .catch(() => {
                            reject();
                        });
                });
            };

            this.downloadDocument = async function downloadDocument() {
                self.downloadFile(this.dataset.url);
            };

            this.removeDocument = async function removeDocument() {
                const $button = $(this);
                try {
                    await self.utils.post(self.utils.getUrl('documents', 'remove'), {
                        filename  : $button.data('filename'),
                        entity_id : AMOCRM.data.current_card.id,
                        entity    : AMOCRM.data.current_entity,
                    });

                    $button.parents('.row-document').remove();
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                }

                $button.trigger('button:load:stop')
                    .trigger('button:enable');

                return false;
            };

            this.generateTemplate = async function generateTemplate() {

                const $this    = $(this);
                const filename = $this.closest('.row-button').data('filename');
                const format   = $this.data('format');
                const contacts = self.getContactsByCurrentLead();

                let contactId;
                try {
                    contactId = contacts.length > 1 ? await self.openModalChooseContact(contacts) : null;
                } catch (e) {
                    self.utils.debug.error(e);

                    return false;
                }

                contactId = contactId || !contacts.length ? contactId : contacts[0].id;

                const generateParams = [
                    AMOCRM.data.current_entity,
                    String(self.getCurrentLeadId()),
                    contactId,
                    filename,
                    format,
                ];

                if (format === 'preview') {
                    self.generatePreview(...generateParams);
                } else {
                    self.generateDocumentByLead(...generateParams);
                }

                return false;
            };

            this.mapSelectedItems = function mapSelectedItems(itemId) {
                if (managersWithGroup.managers[itemId]) {
                    return {
                        active    : managersWithGroup.managers[itemId].active,
                        group     : managersWithGroup.managers[itemId].group,
                        id        : managersWithGroup.managers[itemId].id,
                        is_group  : false,
                        name      : managersWithGroup.managers[itemId].title,
                        raw_title : managersWithGroup.managers[itemId].title,
                        title     : managersWithGroup.managers[itemId].title,
                    };
                } else {
                    return {
                        group     : 'y',
                        id        : itemId,
                        is_group  : true,
                        name      : managersWithGroup.groups[itemId],
                        raw_title : managersWithGroup.groups[itemId],
                        title     : managersWithGroup.groups[itemId],
                    };
                }
            };

            this.saveGeneralSettings = function saveGeneralSettings(settingName, value) {
                return self.utils.post(self.utils.getUrl('settings', 'save_general_settings'), {
                    [settingName] : value,
                });
            };

            this.payTariff = async function payTariff() {
                const tariffSlug = this.parentNode.parentNode.dataset.slug;

                const response = await self.utils.post(self.utils.getUrl('payment', 'pay'), {
                    slug      : tariffSlug,
                    promocode : $('#getdoc-promocode').val(),
                });

                let form = '<form action="https:/' + '/www.platron.ru/payment.php" method="post">';
                for (let key in response) {
                    if (response.hasOwnProperty(key)) {
                        form += '<input type="hidden" name="' + key + '" value="' + response[key] + '" />';
                    }
                }
                form += '</form>';
                form = $(form);

                $('body').append(form);
                form.submit();
            };

            this.addGroup = (function () {
                let $templatesTable = null;
                let $readyTemplate  = null;
                return async function addGroup() {
                    if (!$templatesTable) {
                        $templatesTable = $('.templates-table', '#tab-templates');
                    }

                    if (!$readyTemplate) {
                        const template = await self.utils.getTemplatePromise(
                            'advanced_settings/tab_templates/template-group');

                        $readyTemplate = $((template).render());
                    }

                    const $groupToAppend = $readyTemplate.clone();
                    self.initSortableFiles($groupToAppend.find('.templates').toArray());

                    $templatesTable.append($groupToAppend);
                    self.saveSort();

                    return false;
                };
            })();

            this.hoverAddGroup = (function () {
                let $ghostTemplate = null;
                return function hoverAddGroup(e) {
                    if (!$ghostTemplate) {
                        $ghostTemplate = $('.templates-group.ghost', '#tab-templates');

                    }

                    $ghostTemplate[e.type === 'mouseenter' ? 'addClass' : 'removeClass']('hover');
                };
            })();

            this.openConfirmationModal = function openConfirmationModal(id, text) {
                return new Promise(async function (resolve) {
                    try {
                        const {$modalBody, modal} = await self.utils.createModal(
                            'confirmation_modal',
                            {
                                text,
                            },
                            {
                                id,
                                destroy() {
                                    resolve(false);
                                },
                            },
                        );

                        $modalBody
                            .trigger('modal:centrify')
                            .trigger('modal:loaded')
                            .on(AMOCRM.click_event, '.cancel, .confirm', function () {
                                resolve(this.classList.contains('confirm'));
                                modal.destroy();
                            });
                    } catch (e) {
                        self.utils.debug.error('Ошибка модалки подтверждения', e);
                    }
                });
            };

            this.becomePartner = async function becomePartner() {
                const userChoice = await self.openConfirmationModal(
                    self.utils.id('partner-modal', false),
                    self.i18n('partner.message'),
                );

                if (userChoice !== true) {
                    return;
                }

                let partnerCode;
                try {
                    partnerCode = await self.utils.post(self.utils.getUrl('widget', 'partner'));
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));
                }

                const partnerTemplate = await self.utils.getTemplatePromise('advanced_settings/tab_pay/partner');

                self.reRenderTabPay(null, null, true);
                window.requestAnimationFrame(function () {
                    $('.partner-program', '#tab-pay')
                        .replaceWith((partnerTemplate.render({
                            partner_code : partnerCode,
                        })));
                });
            };

            this.reRenderTabPay = async function reRenderTabPay(response, promocode, cancel = false) {
                const $tabPay = $('#tab-pay');
                if (cancel) {
                    window.requestAnimationFrame(() => {
                        if (this.$oldTabPay) {
                            $tabPay.replaceWith(this.$oldTabPay);
                        }
                    });

                    return;
                }

                this.$oldTabPay      = $tabPay.clone();
                const tabPayTemplate = await self.utils.getTemplatePromise('advanced_settings/tab_pay/tab');
                const $newTabPay     = $(tabPayTemplate.render({
                    code              : response.code,
                    tariffs           : {
                        items : response.tariffs,
                    },
                    partner           : {
                        partner_code : response.partner_code,
                    },
                    promocode,
                    generation_notify : response.generation_notify,
                }));

                window.requestAnimationFrame(() => {
                    $tabPay.replaceWith($newTabPay);
                });

                return $newTabPay;
            };

            this.onGroupClick = function (e) {
                if (e.target !== this) {
                    return true;
                }

                const {groupId}  = this.dataset;
                const $group     = $(this);
                const groupItems = $group.siblings(`.checkboxes_dropdown__item[data-group-id="${groupId}"]`)
                    .add(this)
                    .toArray()
                    .map(item => $(item).find('.checkboxes_dropdown__label:not(.hidden)'))
                    .filter(found => found.length);
                const checked    = groupItems.map(item => item.hasClass('is-checked'));
                const allChecked = checked.every(_.identity);

                $(groupItems)
                    .each((index, item) => $(item)
                        .find('input[type="checkbox"]')
                        .prop('checked', !allChecked)
                        .trigger('change'),
                    );
            };

            this.searchManagersSelect = function () {
                const $input               = $(this);
                const searchQuery          = $input.val().toLocaleLowerCase();
                const $chkDrd              = $input.parents('.checkboxes_dropdown');
                const $labels              = $chkDrd.find('.checkboxes_dropdown__label');
                const countManagersByGroup = {};

                $labels
                    .removeClass('hidden')
                    .toArray()
                    .map(label => label.querySelector('.checkboxes_dropdown__label_title'))
                    .forEach(labelTitle => {
                        if (labelTitle.title.toLowerCase().includes(searchQuery)) {
                            labelTitle.parentNode.classList.remove('hidden');

                        } else {
                            labelTitle.parentNode.classList.add('hidden');
                            const {groupId} = labelTitle.parentNode.parentNode.dataset;
                            if (_.isUndefined(countManagersByGroup[groupId])) {
                                countManagersByGroup[groupId] = 0;
                            }

                            countManagersByGroup[groupId]++;
                        }
                    });

                $chkDrd
                    .find('.checkboxes_dropdown__label_title_divider_before')
                    .each((index, divider) => {
                        const {groupId, countManagers} = divider.dataset;
                        if ((+countManagers + 1) === countManagersByGroup[groupId]) {
                            divider.classList.add('hidden');
                        } else {
                            divider.classList.remove('hidden');
                        }
                    });
            };

            this.debouncedSearchManagersSelect = _.debounce(self.searchManagersSelect, 200);

            this.controlsHide = function (e) {
                _.defer(() => {
                    const $dropdown   = $(e.target);
                    const selectedIds = $dropdown.find('.manager-select-item input:checked')
                        .toArray()
                        .map(input => input.value);

                    $(this)
                        .parents('.manager-select')
                        .trigger('managerselect:change' + self.ns, [selectedIds]);
                });
            };

            this.managerSelectChange = function (e, selectedIds) {
                const $searchInput = $(e.target).find('.search-wrapper').find('input');
                $searchInput.val() && $searchInput.val('').trigger('input');
                self.saveGeneralSettings(e.target.dataset.id, _.isEmpty(selectedIds) ? null : selectedIds)
                    .then(function () {
                        const $accessRightsDisabled = $('.access-rights-disabled', '#tab-settings');
                        if ($accessRightsDisabled.length) {
                            $accessRightsDisabled.remove();
                        }
                    });
            };

            this.activatePromocode = async function activePromocode() {
                const $promocode = $('#getdoc-promocode');
                const promocode  = $promocode.val();

                if (!promocode) {
                    self.utils.error(self.i18n('error.promocode.not_empty'), self.i18n('error.promocode.header'));
                    self.addWrongInputStyle($promocode);

                    return;
                }

                const response = await self.utils.post(self.utils.getUrl('payment', 'get_promocode_prices'), {
                    promocode,
                });

                const $reRenderedTab = await self.reRenderTabPay(response, promocode);

                if (!response.promocode_success) {
                    self.utils.error(self.i18n('error.promocode.wrong'), self.i18n('error.promocode.header'));
                    self.addWrongInputStyle($('#getdoc-promocode', $reRenderedTab));
                }
            };

            this.addWrongInputStyle = function ($inputEl) {
                $inputEl
                    .addClass('get8-error')
                    .one('focus', () => $inputEl.removeClass('get8-error'));
            };

            this.clickMultisuggest = function clickMultisuggest() {
                self.initManagersWithGroup({currentTarget : $(this).closest('.manager-select')[0]});
            };

            this.getPlaceholderCode = function getPlaceholderCode() {
                const chosenField = $('#placeholder_field_select').val();

                if (!chosenField) {
                    return '';
                }

                const chosenFilters = $('.multichooser-to', '#tab-placeholders')
                    .find('li')
                    .toArray()
                    .map(li => li.dataset.id)
                    .join('-');
                const required      = $('#placeholder_reqiured').prop('checked');

                return `{{${chosenField}${chosenFilters ? '-' + chosenFilters : ''}${required ? '' : '-not_require'}}}`;
            };

            this.updatePlaceholderFields = function updatePlaceholderFields() {
                const $placeholderSelectField    = $('#placeholder_field_select').closest('.control--select');
                const $newPlaceholderSelectField = $(self.render(
                    {ref : '/tmpl/controls/select.twig'},
                    {
                        items : placeholders[this.value],
                        id    : $placeholderSelectField.find('input').attr('id'),
                    },
                ));

                window.requestAnimationFrame(() => $placeholderSelectField
                    .replaceWith($newPlaceholderSelectField),
                );
            };

            this.testPlaceholder = _.throttle(async function testPlaceholder() {
                const placeholder = $('#placeholder-generated').val();
                const testData    = $('#test_placeholder_value').val();

                if (!testData) {
                    return;
                }

                const testPromise = self.utils.post(self.utils.getUrl('placeholder', 'test'), {
                    data        : testData,
                    placeholder : placeholder.trim().substr(2, placeholder.length - 4),
                });

                $('#test_placeholder_result').val(await testPromise);
            }, 1000, {leading : false});

            this.fillGeneratedPlaceholder = function fillGeneratedPlaceholder() {
                window.requestAnimationFrame(function () {
                    $('#placeholder-generated').val(self.getPlaceholderCode());
                });
            };

            this.fillGeneratedPlaceholderDebounced = _.debounce(self.fillGeneratedPlaceholder, 200);

            this.flushMultichooser = function () {
                if (!this.$multichooser) {
                    this.$multichooser = $('.getdoc-multichooser', '#tab-placeholders');
                }

                this.$multichooser.trigger('filter:flush');
            };

            this.copyPlaceholder = function () {
                if (!this.$placeholderGenerated) {
                    this.$placeholderGenerated = $('#placeholder-generated');
                }

                this.$placeholderGenerated.select();

                if (document.queryCommandSupported('copy')) {
                    document.execCommand('copy');
                }
            };

            this.changeTemplateVisibility = async function changeTemplateVisibility() {
                const $template = $(this).parents('.getdoc-template');
                try {
                    const response = await self.utils.post(self.utils.getUrl('templates', 'visible'), {
                        filename : $template.data('fileName'),
                        visible  : this.checked,
                    });
                    $template.data('visible', this.checked);
                    $template.data('fileName', response.name);
                    $template.data('fileUrl', response.url);
                } catch (error) {
                    self.utils.error(self.i18n('error.error') && error && error.error, self.i18n('error.server'));

                    this.checked = !this.checked;
                }
            };

            this.getInputValue = function (input) {
                switch (input.type) {
                    case 'checkbox':
                        return input.checked;
                    case 'number':
                        return +input.value;
                    default:
                        return input.value;
                }
            };

            this.setInputValue = function (input, value) {
                switch (input.type) {
                    case 'checkbox':
                        input.checked = !!value;

                        break;
                    case 'number':
                    default:
                        input.value = value;
                }
            };

            this.getBalanceNotifySettings = function getBalanceNotifySettings() {
                const $notificationInputs = $('.package-notifications', '#tab-pay')
                    .find('.suboptions__content')
                    .find('input');

                return $notificationInputs
                    .toArray()
                    .reduce((acc, cur) => {
                        acc[cur.name] = self.getInputValue(cur);

                        return acc;
                    }, {});
            };

            this.stringToLowerCase = function (string) {
                return string.toLowerCase();
            };

            this.validateEmail = function (email) {
                return EMAIL_REGEXP.test(email);
            };

            this.validateEmailString = function (emails) {
                if (!emails) {
                    return true;
                }

                return emails
                    .split(';')
                    .map(self.stringToLowerCase)
                    .every(self.validateEmail);
            };

            this.saveBalanceNotify = function (balanceNotify) {
                return self.saveGeneralSettings('generation_notify', JSON.stringify(balanceNotify));
            };

            this.rollbackBalanceNotifySettings = function () {
                const $notificationInputs = $('.package-notifications', '#tab-pay')
                    .find('.suboptions__content')
                    .find('input');

                $notificationInputs.each(function (index, input) {
                    self.setInputValue(input, balanceNotifySettings[input.name]);
                });
            };

            this.validateAndSaveBalanceNotify = function () {
                const newBalanceNotifySettings = self.getBalanceNotifySettings();

                if (!self.validateEmailString(newBalanceNotifySettings.emails)) {
                    $('#generation_notify__emails', '#tab-pay')
                        .addClass('get8-error')
                        .one('input', function () {
                            $(this).removeClass('get8-error');
                        });

                    newBalanceNotifySettings.emails = balanceNotifySettings.emails;
                }

                if (_.isEqual(balanceNotifySettings, newBalanceNotifySettings)) {
                    return Promise.resolve();
                }

                return self.saveBalanceNotify(newBalanceNotifySettings)
                    .then(function () {
                        balanceNotifySettings = newBalanceNotifySettings;
                    })
                    .catch(error => {
                        self.rollbackBalanceNotifySettings();
                        self.utils.error(error);
                    });
            };

            this.validateAndSaveBalanceNotifyDebounced = _.debounce(self.validateAndSaveBalanceNotify, 500);

            this.getManagersWithGroup = function getManagersWithGroup() {
                if (AMOCRM.constant('loaded_users')) {
                    return Promise.resolve(AMOCRM.constant('loaded_users'));
                }

                return self.utils.post('/ajax/get_managers_with_group/');
            };

            this.advancedSettingsLoader = function advancedSettingsLoader(show) {
                if (show) {
                    $(document).trigger('page:overlay:show');
                } else {
                    setTimeout(function () {
                        $(document).trigger('page:overlay:hide');
                    }, 300);
                }
            };

            this.prepareDataForAdvancedSettings = function prepareDataForAdvancedSettings(response) {
                const gift                    = response.gift || {};
                const groupNames              = AMOCRM.constant('groups');
                const managerToDropdown       = _.chain(AMOCRM.constant('managers'))
                    .reduce(function (acc, item) {
                        if (!acc[item.group]) {
                            acc[item.group] = [];
                        }

                        if (item.active) {
                            acc[item.group].push(item);
                        }

                        return acc;
                    }, {})
                    .map(function (groupItems, groupId) {
                        const restManagers = _.rest(groupItems);
                        const firstManager = {
                            ...groupItems[0],
                            divider_before  : {title : groupNames[groupId]},
                            additional_data : `data-count-managers=${restManagers.length} data-group-id=${groupId}`,
                        };

                        return [
                            firstManager,
                            ...restManagers.map(item => ({...item, additional_data : `data-group-id=${groupId}`})),
                        ];
                    })
                    .flatten()
                    .value();
                const managerVisibility       = new Set(response.settings.manager_visibility);
                const generateManagers        = new Set(response.settings.generate_managers);
                const managersDeleteGenerated = new Set(response.settings.managers_delete_generated);
                return {
                    gift_received    : gift.gift_received === undefined ? true : gift.gift_received,
                    tab_description  : {
                        avatar : self.params.path + '/images/mihail.jpg',
                    },
                    tab_settings     : {
                        access_rights_enabled     : response.settings.access_rights_enabled,
                        manager_visibility        : managerToDropdown.map(
                            item => ({...item, is_checked : managerVisibility.has(item.id)})),
                        generate_managers         : managerToDropdown.map(
                            item => ({...item, is_checked : generateManagers.has(item.id)})),
                        managers_delete_generated : managerToDropdown.map(
                            item => ({...item, is_checked : managersDeleteGenerated.has(item.id)})),
                        active_getfile            : response.settings.active_getfile,
                        backup_on_getfile         : response.settings.backup_on_getfile,
                    },
                    tab_placeholders : {
                        placeholders_steps : [
                            {
                                items : [
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.0'),
                                        id     : 'gl',
                                    },
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.1'),
                                        id     : 'ld',
                                    },
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.2'),
                                        id     : 'cn',
                                    },
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.3'),
                                        id     : 'cm',
                                    },
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.4'),
                                        id     : 'us',
                                    },
                                    {
                                        option : self.i18n(
                                            'templates.advanced_settings.tab_placeholders.select.0.items.5'),
                                        id     : 'ct',
                                    },
                                ],
                                id    : 'placeholder_entity_select',
                            },
                            {
                                items : response.placeholders.gl,
                                id    : 'placeholder_field_select',
                            },
                            {
                                items : response.filters,
                                id    : 'placeholder_filter_select',
                            },
                        ],
                    },
                    tab_templates    : {
                        entities  : {
                            us : self.i18n('js.user_fields'),
                            ld : self.i18n('js.lead_fields'),
                            cm : self.i18n('js.company_fields'),
                            cn : self.i18n('js.contact_fields'),
                        },
                        templates : {
                            groups : self.prepareSort(
                                response.sort,
                                response.templates,
                            ),
                        },
                    },
                    tab_pay          : {
                        installed         : true,
                        number            : response.tariffs.number,
                        code              : response.tariffs.code,
                        tariffs           : {
                            items : response.tariffs.tariffs,

                        },
                        partner           : {
                            partner_code : response.partner_code,
                        },
                        generation_notify : response.settings.generation_notify || {},
                    },
                };
            };

            this.renderWidget = (function () {
                let rendered = false;
                return async function renderWidget() {
                    if (rendered) {
                        return;
                    }
                    rendered = true;

                    self.utils.appendCss(
                        'https://fonts.googleapis.com/css?family=Montserrat:400,600&amp;subset=cyrillic',
                        true,
                    );

                    try {
                        const [template, {templates, sort, documents, paid, rights}] = await Promise.all([
                            self.utils.getTemplatePromise('widget'), self.getSettingsForRightWidget(),
                        ]);

                        userRights = rights;
                        $rightWidget
                            .find(' .widget-wrap')
                            .html(
                                template.render({
                                    templates : self.prepareSort(sort, templates),
                                    timezone  : AMOCRM.system.timezone,
                                    documents,
                                    paid,
                                    rights,
                                }),
                            )
                            .css('min-height', 'auto');
                    } catch (error) {
                        self.utils.error(error, self.i18n('error.get_templates'));

                    }
                };
            })();

            this.initMultichooser = function initMultichooser($multichooser, filters) {
                Sortable.create($multichooser.find('.multichooser-to ul')[0], {
                    filter : '.delete',
                    onFilter(e) {
                        const $item  = $(e.item);
                        const dataId = $item.data('id');

                        $multichooser.find('.multichooser-from li[data-id="' + dataId + '"]').removeClass('used');
                        $item.remove();
                        self.fillGeneratedPlaceholderDebounced();
                    },
                    onEnd  : self.fillGeneratedPlaceholderDebounced,
                });

                $multichooser.on('filter:flush', function () {
                    $multichooser
                        .find('.multichooser-to')
                        .find('li')
                        .remove();

                    $multichooser
                        .find('.multichooser-from')
                        .find('li.used')
                        .removeClass('used');
                });

                $multichooser.find('.add').on('click', async function () {
                    const $filter  = $(this).parent();
                    const filterId = $filter.data('id');

                    $filter.addClass('used');

                    if (!filters.hasOwnProperty(filterId)) {
                        return false;
                    }

                    const filterData   = filters[filterId];
                    const itemTemplate = await self.utils.getTemplatePromise(
                        'advanced_settings/tab_placeholders/multichooser-item');

                    $multichooser.find('.multichooser-to ul')
                        .append(itemTemplate.render({
                            id          : filterData.id,
                            text        : filterData.text,
                            name        : filterData.name,
                            from        : filterData.from,
                            to          : filterData.to,
                            isDeletable : true,
                        }));

                    self.fillGeneratedPlaceholderDebounced();

                    return false;
                });

                const liForSearch = $multichooser.find('.multichooser-from').find('li').toArray();
                $multichooser.find('input[name="multichooser-from"]').on('input', _.debounce(function () {
                    const val = $(this).val().toLowerCase();

                    liForSearch.forEach(li => {
                        const $li = $(li);
                        if (filters[li.dataset.id].name.toLowerCase().includes(val)
                            || filters[li.dataset.id].text.toLowerCase().includes(val)
                        ) {
                            $li.show();
                        } else {
                            $li.hide();
                        }
                    });

                }, 300));
            };

            this.getSettingsForDp = function getSettingsForDp() {
                return self.utils.get(self.utils.getUrl('settings', 'get_dp'), {
                    'entity_id' : self.getCurrentLeadId(),
                    'entity'    : AMOCRM.data.current_entity,
                });
            };

            this.memoizedSettingsForDp = _.memoize(self.getSettingsForDp);

            this.jsonParseWithDefaultValue = function (jsonString, defaultValue = null) {
                try {
                    return JSON.parse(jsonString);
                } catch (e) {
                    return defaultValue;
                }
            };

            this.prepareDpSettings = async function ($settingsInput) {
                const serverSettings = await self.memoizedSettingsForDp();
                const templates      = [...serverSettings.templates];
                const extensions     = [...serverSettings.extensions];
                const dpSettings     = {
                    accountId  : AMOCRM.constant('account').id,
                    templates  : {
                        items : templates,
                        name  : 'filename',
                    },
                    extensions : {
                        items : extensions,
                        name  : 'extension',
                    },
                    errors     : {},
                };

                const currentSettings = self.jsonParseWithDefaultValue($settingsInput.val(), {});

                if (currentSettings.filename && currentSettings.filename !== 'false') {
                    dpSettings.templates.selected = currentSettings.filename;

                    if (!_.pluck(templates, 'id').includes(currentSettings.filename)) {
                        dpSettings.templates.items.unshift({
                            id         : currentSettings.filename,
                            option     : currentSettings.filename,
                            disabled   : true,
                            class_name : 'deleted',
                        });
                        dpSettings.errors.filename = currentSettings.filename;
                    }
                } else {
                    dpSettings.templates.selected = templates && templates[1]
                        ? templates[1].id
                        : null;
                }

                if (currentSettings.extension && currentSettings.extension !== 'false') {
                    dpSettings.extensions.selected = currentSettings.extension;

                    if (!_.pluck(extensions, 'id').includes(currentSettings.extension)) {
                        dpSettings.extensions.items.unshift({
                            id         : currentSettings.extension,
                            option     : currentSettings.extension,
                            disabled   : true,
                            class_name : 'deleted',
                        });
                        dpSettings.errors.extension = currentSettings.extension;
                    }
                } else {
                    dpSettings.extensions.selected = extensions && extensions[1]
                        ? extensions[1].id
                        : null;
                }

                return dpSettings;
            };

            this.renderDpSettings = async function ({$dpEditBubble, $settingsBlock, $settingsInput, $saveBtn}) {
                $dpEditBubble.attr('id', self.widgetCode + '_dp');
                self.utils.appendCss('dp');

                const dpTemplate       = self.utils.getTemplatePromise('dp/main');
                const dpSettings       = await self.prepareDpSettings($settingsInput);
                const renderedTemplate = (await dpTemplate).render(dpSettings);

                $settingsBlock.append(renderedTemplate);

                $saveBtn
                    .off(clickNs)
                    .trigger('button:load:stop')
                    .on(clickNs, () => {
                        const newSettings = $settingsBlock.find('input:not(:first)')
                            .toArray()
                            .reduce((obj, input) => (obj[input.name] = input.value, obj), {});

                        $settingsInput.val(JSON.stringify(newSettings));
                    });
            };

            this.stopPropagation = e => {
                e.stopPropagation();
            };

            this.callbacks = {
                dpSettings() {
                    const $dpEditBubble  = $('.digital-pipeline__edit-bubble', '#list_holder');
                    const $settingsBlock = $('.widget_settings_block__fields', $dpEditBubble);
                    const $settingsInput = $('#settings', $dpEditBubble);
                    const $saveBtn       = $('.js-trigger-save', $dpEditBubble);

                    $settingsBlock.children().first().hide();

                    $saveBtn
                        .trigger('button:load:start')
                        .on(clickNs, () => false);

                    self.renderDpSettings({$dpEditBubble, $settingsBlock, $settingsInput, $saveBtn});
                },

                async advancedSettings() {
                    if (self.params.already_installed !== 'Y'){
                        return;
                    }

                    self.advancedSettingsLoader(true);

                    const [settingsPromise, mainTemplatePromise] = await Promise.all([
                        self.utils.getSettings(),
                        self.utils.getTemplatePromise('advanced_settings/main'),
                    ]);

                    managersWithGroup     = await self.getManagersWithGroup();
                    balanceNotifySettings = settingsPromise.settings.generation_notify || {};

                    $('#work_area')
                        .addClass('amo_getdoc')
                        .find('.list__body-right__top')
                        .hide();

                    self.utils.appendCss('advanced');

                    const templateSettings = self.prepareDataForAdvancedSettings(settingsPromise);
                    const $mainTemplate    = $((mainTemplatePromise).render(templateSettings));
                    const $tabTemplates    = $mainTemplate.find('#tab-templates');
                    const $tabPlaceholders = $mainTemplate.find('#tab-placeholders');

                    placeholders = (settingsPromise).placeholders;
                    self.initSortableGroups($tabTemplates.find('.templates-table')[0]);
                    self.initSortableFiles($tabTemplates.find('.templates').toArray());
                    self.initFileUpload($tabTemplates.find('#upload-templates'));
                    self.initMultichooser($tabPlaceholders.find('.getdoc-multichooser'), (settingsPromise).filters);
                    $mainTemplate
                        .find('.manager-select .checkboxes_dropdown__list')
                        .on('controls:hide', self.controlsHide);

                    $('#work-area-' + self.params.widget_code).append($mainTemplate);
                    self.fillGeneratedPlaceholderDebounced();

                    self.advancedSettingsLoader(false);

                    giftData = {...settingsPromise.gift};
                    if (settingsPromise.gift && settingsPromise.gift.first_show) {
                        self.createGiftModal();
                    }

                    $('button.getdoc_save_document_generations').each(function(index, button) {$(button).prop("disabled",true)});
                },

                init() {
                    self.widgetIsActive = self.params.widget_active && self.params.widget_active === 'Y';
                    if (self.widgetIsActive && self.params.already_installed === 'Y'
                        && (currentArea === SUPPORTED_AREA.settings || currentArea === SUPPORTED_AREA.advancedSettings)) {
                        self.utils.updateUserInfo()
                            .catch(e => self.utils.debug.error('Не удалось обновить данные пользователя ', e));
                    }

                    return true;
                },

                bind_actions() {
                    if (!self.widgetIsActive) {
                        return true;
                    }

                    switch (currentArea) {
                        case SUPPORTED_AREA.advancedSettings: {
                            $(document)
                                .on(clickNs, '.group-remove', self.groupDelete)
                                .on(clickNs, '.group-header', self.toggleTemplates)
                                .on(clickNs, '.group-rename', self.renameGroup)
                                .on(focusoutNs, '.group-header .name', self.blurRenameGroup)
                                .on(focusoutNs, '.getdoc-template .name[contenteditable=true]', self.blurRenameTemplate)
                                .on(keydownNs, '.group-header .name, .getdoc-template .name', self.onPressEnter)
                                .on(clickNs, '.group-template-upload', self.uploadTemplatesClick)
                                .on(clickNs, ' .download-template', self.downloadTemplate)
                                .on(clickNs, '.getdoc-template .name, .toggle-more-info', self.toggleMoreInfo)
                                .on(clickNs, ' .preview-template', self.previewTemplate)
                                .on(clickNs, ' .getdoc_save_document_generations', self.saveDocumentGenerations)
                                .on(clickNs, ' .delete-template', self.deleteTemplate)
                                .on(clickNs, ' .rename-template', self.renameTemplate)
                                .on(clickNs, '.package__pay button', self.payTariff)
                                .on(clickNs, '#btn-add-group', self.addGroup)
                                .on(hoverNs, '#btn-add-group', self.hoverAddGroup)
                                .on(clickNs, '#getdoc-become-partner', self.becomePartner)
                                .on(clickNs, '#getdoc-active-promocode', self.activatePromocode)
                                .on(inputNs, '.managers-select-search', self.debouncedSearchManagersSelect)
                                .on(clickNs, '.managers-select-search', self.stopPropagation)
                                .on(clickNs, 'input.getdoc_input_file_generations', self.changeInTheNumberOfGenerations)
                                .on(
                                    'mouseup',
                                    '.manager-select-item.checkboxes_dropdown__label_title_divider_before',
                                    self.onGroupClick,
                                )
                                .on('managerselect:change' + self.ns, self.managerSelectChange)
                                .on(changeNs, '#placeholder_entity_select', self.updatePlaceholderFields)
                                .on(changeNs, '#placeholder_entity_select', self.updatePlaceholderFields)
                                .on(clickNs, '#test_palceholder', self.testPlaceholder)
                                .on(
                                    changeNs,
                                    '#placeholder_entity_select,' +
                                    ' #placeholder_field_select,' +
                                    ' #placeholder_reqiured',
                                    self.fillGeneratedPlaceholderDebounced,
                                )
                                .on(
                                    changeNs,
                                    '#placeholder_entity_select,' +
                                    ' #placeholder_field_select',
                                    self.flushMultichooser,
                                )
                                .on(controlsChangeNs, '.checkboxes_dropdown', self.fillGeneratedPlaceholderDebounced)
                                .on(clickNs, '#placeholder-generated-copy', self.copyPlaceholder)
                                .on(changeNs, '.template-visibility', self.changeTemplateVisibility)
                                .on(changeNs, '#backup_on_getfile', function () {
                                    self.saveGeneralSettings(this.name, this.checked);
                                })
                                .on(
                                    changeNs,
                                    '.package-notifications .suboptions__content input',
                                    self.validateAndSaveBalanceNotifyDebounced,
                                )
                                .on(
                                    clickNs,
                                    '.get-generations',
                                    self.buttonWithLoading(self.createGiftModal),
                                );

                            break;
                        }
                        case SUPPORTED_AREA.lcard: {
                            if (AMOCRM.data.current_card.id === 0) {
                                return true;
                            }

                            $(document)
                                .on(clickNs, self.utils.id() + ' .template-title', self.toggleTemplates)
                                .on(clickNs, self.utils.id() + ' .document-download', self.downloadDocument)
                                .on(clickNs, self.utils.id() + ' .document-remove', self.removeDocument)
                                .on(clickNs, self.utils.id() + ' .generate-template', self.generateTemplate);

                            $rightWidget.one(clickNs, self.renderWidget);

                            break;
                        }
                        default: {
                            return true;
                        }
                    }

                },

                render() {
                    currentArea = AMOCRM.getV3WidgetsArea();
                    if (currentArea === SUPPORTED_AREA.settings
                        || currentArea === SUPPORTED_AREA.advancedSettings
                        || (AMOCRM.data.is_card && AMOCRM.data.current_card.id === 0)) {
                        return true;
                    }

                    self.utils.appendCss('widget');
                    self.render_template({
                        caption : {
                            class_name : 'title-wrap',
                            html       : '',
                        },
                        body    : '',
                        render  : '<div class="wrapper"><div class="widget-wrap"></div></div>',
                    });

                    $rightWidget = $(
                        '.card-widgets__widget[data-code="' + self.params.widget_code + '"]',
                        '#nano-card-widgets',
                    ).attr('id', self.utils.id('', false));


                    const $sideGroup = $('#get8SideGroup', '#nano-card-widgets');
                    if ($sideGroup.length) {
                        $sideGroup.append($rightWidget);
                    } else {
                        $rightWidget.wrap('<div id="get8SideGroup" '
                            + 'style="background: linear-gradient(135.54deg, #138ff5 -15%, #d75298 50.01%, #ff0000 115%);">'
                            + '</div>');
                    }

                    self.loader($rightWidget.find('.widget-wrap'));

                    return true;
                },

                settings($modalBlock) {
                    self.utils.appendCss('settings5');

                    const $modalBody           = $modalBlock.parents('.modal-body');
                    const $install             = $modalBody.find(`#${self.params.widget_code}`);
                    const $save                = $modalBody.find(`#save_${self.params.widget_code}`);
                    const $fieldAlreadyInstall = $('input#already_installed');
                    const firstInstall         = $fieldAlreadyInstall.val() === '';
                    

                    $save.removeClass('button-input-disabled').addClass('button-input_blue').text(self.i18n('settings.end_install'));

                    if (self.params.already_installed === 'Y'){
                        $save.hide();
                    }
                    
                    $modalBody.attr('id', self.utils.id('', false));

                    self.utils.getTemplatePromise('description')
                        .then(template => {
                            $modalBody
                                .find('.widget_settings_block .widget_settings_block__descr')
                                .after(
                                    template.render({
                                        widget_path      : self.params.path,
                                        widget_installed : self.params.already_installed === 'Y',
                                        widget_code      : self.params.widget_code,
                                        first_install    : self.params.already_installed !== 'Y',
                                    }),
                                );

                            $modalBody
                                .show()
                                .trigger('modal:centrify');
                        });
                    
                    $(document)
                        .off(`${widgetInstalled} ${widgetRemoved}`)
                        .on(
                            `${widgetInstalled} ${widgetRemoved}`,
                            _.defer.bind(null, self.modal.renderModal.bind(self.modal)),
                        );

                        $modalBody
                            .off(self.ns)
                            .on(AMOCRM.click_event + self.ns, `#save_${self.params.widget_code}`, function (e, savedOnServer) {
                                if (savedOnServer) {
                                    return;
                                }

                                e.stopPropagation();
                                e.preventDefault();

                                save($(this), self.params.already_installed !== 'Y');
                            }).on(AMOCRM.click_event + self.ns, `#${self.params.widget_code}`, function (e, savedOnServer) {
                                if (self.params.already_installed !== 'Y') {
                                    return;
                                }

                                if (savedOnServer) {
                                    return;
                                }

                                if (self.params.already_installed === 'Y'){
                                    save($(this));
                                }
                            });

                    let save = function($button, $firstInstall = false) {
                        $button.trigger('button:load:start');

                        const $agreeWrapper = $('.agree-wrapper', self.modal.$modal);

                        if ($agreeWrapper.length) {
                            if ($agreeWrapper.find('input[type="checkbox"]').is(':checked')) {
                                $agreeWrapper.removeClass('error-block');
                            } else {
                                $agreeWrapper.addClass('error-block');
                                
                                $button
                                    .trigger('button:save:error');

                                return false;
                            }
                        }

                        let request;
                        if ($firstInstall) {
                            request = self.utils.post(self.utils.getUrl('widget', 'status'), {
                                status             : 'install',
                                partner_install    : $('#partner-install-getdoc', self.modal.$modal).is(':checked'),
                                agree_email_notify : $('#agree_email_notify', self.modal.$modal).is(':checked'),
                            });
                        } else {
                            request = self.utils.post(self.utils.getUrl('widget', 'status'), {
                                status : $button.hasClass('install-widget__button') ? 'active' : 'deactive',
                            });
                        }

                        request
                            .then(function () {
                                    self.params.already_installed = 'Y';
                                    $('input#already_installed').val('Y');
                                    if ($button.hasClass('js-widget-uninstall')) {
                                        $button.trigger('button:disable')
                                    } else {
                                        $button.trigger('button:load:stop')
                                            .trigger('button:save:enable');
                                        $(`#save_${self.params.widget_code}`).trigger(AMOCRM.click_event, [true]);
                                    }

                            })
                            .catch(function() {
                                $button.trigger('button:load:stop')
                                    .trigger('button:save:enable');
                            });
                    }

                    return true;
                },

                onSave() {
                    return true;
                },

                destroy() {
                    $(document).off(eventNamespace);

                    return true;
                },
            };

            if (self.debugMode) {
                const functionWithDebug = function (func) {
                    return function () {
                        const uniqName = _.uniqueId(`${func.name || 'anonymous'}_`);
                        self.utils.debug.groupCollapsed(uniqName);
                        self.utils.debug.log(`Вызов функции: ${func.name}. С аргументами:`, arguments);
                        self.utils.debug.time(uniqName);
                        const result = func.apply(this, arguments);
                        self.utils.debug.log('Результат:', result);
                        self.utils.debug.timeEnd(uniqName);
                        self.utils.debug.groupEnd();
                        return result;
                    };
                };

                const widgetOwnKeys     = Reflect.ownKeys(self);
                const excludedFunctions = [
                    'utils',
                ];
                for (const prop in self) {
                    if (self.hasOwnProperty(prop)
                        && !excludedFunctions.includes(prop)
                        && widgetOwnKeys.includes(prop)
                        && typeof (self[prop]) === 'function'
                    ) {
                        self[prop] = functionWithDebug(self[prop]);
                    }
                }
            }

            return this;
        };
    },
);
