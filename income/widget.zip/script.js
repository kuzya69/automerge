window.GT4U = {
    name: 'GT4U Platform',
    isLoaded: false,
    domain: 'https://gt4u-vps.ru',
    init: () => {
        if (false === GT4U.isLoaded){
            define([GT4U.getCoreLink()], a => a);

            GT4U.checkCoreLoad(25);
        }
    },
    getCoreLink: () => {
        const url = new URL(`${GT4U.domain}/api/widget/core/${GT4U.getAccountId()}`);
        url.searchParams.set('subdomain', GT4U.getAccountSubdomain());

        return require.toUrl(url.href);
    },
    getAccount: () => AMOCRM.constant('account'),
    getAccountId: () => GT4U.getAccount().id,
    getAccountSubdomain: () => GT4U.getAccount().subdomain,
    checkCoreLoad: seconds => {
        const timeout = seconds * 1000;
        setTimeout(() => {
            if (false === GT4U.isLoaded)
            {
                GT4U.showNotificationError('Не удалось загрузить виджеты!');
            }
        }, timeout)
    },
    showNotificationError: (text, callbacks) => {
        callbacks = typeof callbacks === 'object' ? callbacks : {};
        const now = Math.ceil(Date.now() / 1000);

        const error = {
            header: GT4U.name,
            text: text,
            date: now
        };

        AMOCRM.notifications.add_error(error, callbacks)
    }
};

GT4U.init();