define(["require", "exports"], function (require, exports) {
    "use strict";
    var Widget = (function () {
        function Widget() {
            var _this = this;
            this.callbacks = {
                render: function () {
                    return true;
                },
                init: function () {
                    return true;
                },
                bind_actions: function () {
                    return true;
                },
                settings: function () {
                    return true;
                },
                onSave: function (data) {
                    return true;
                },
                contacts: {
                    selected: function () {
                    }
                },
                leads: {
                    selected: function () {
                    }
                },
                tasks: {
                    selected: function () {
                    }
                }
            };
        }
        return Widget;
    }());
    return Widget;
});