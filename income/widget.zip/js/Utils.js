define(['jquery', 'lib/components/base/modal', 'json!../manifest.json'], function ($, Modal, manifest) {
    return function (widget) {
        const self = this;

        this.getUrl = function (controller, method, params = {}) {
            const requestParams = $.param($.extend(params, self.defaultParams));

            return '/' + '/v2.widget8.ru/getdoc/' + controller + '/' + method + '?' +
                (requestParams ? requestParams : '');
        };

        this.defaultParams = (function () {
            const getMainDomain = function () {
                const matches = AMOCRM.widgets.system.domain.match(/[^.]+.[^.]+$/i);

                return matches ? matches.shift() : null;
            };

            return {
                amo_domain  : widget.system().subdomain,
                amo_email   : widget.system().amouser,
                account_id  : AMOCRM.constant('account').id,
                user_id     : AMOCRM.constant('user').id,
                user_group  : AMOCRM.constant('managers') && AMOCRM.constant('managers')[AMOCRM.constant('user').id].group,
                amo_key     : widget.system().amohash,
                main_domain : getMainDomain(),
                lang        : AMOCRM.lang_id,
                version     : manifest.widget.version,
            };
        })();

        this.error = function (text, header = '') {
            if (!text || typeof text !== 'string') {
                return;
            }

            AMOCRM.notifications.add_error({
                header : 'GetDoc: ' + header,
                text   : text,
                date   : Math.ceil(Date.now() / 1000),
            });
        };

        this.debug = (function () {
            if (widget.debugMode) {
                return console;
            }

            const nullLogger = () => true;
            return {
                log            : nullLogger,
                groupCollapsed : nullLogger,
                time           : nullLogger,
                timeEnd        : nullLogger,
                groupEnd       : nullLogger,
                error          : nullLogger,
            };
        })();

        this.id = function (postfix = '', hash = true) {
            return (hash ? '#' : '') + widget.widgetCode + '_widget' + (postfix ? '_' + postfix : '');
        };

        this.getTemplatePromise = function (templateName) {
            return new Promise(function (resolve) {
                widget.render({
                    href      : widget.baseTemplates + templateName + '.twig',
                    base_path : '/',
                    v         : widget.version,
                    load(template) {
                        resolve({
                            render : (data = {}) => template.render(Object.assign({}, data, {
                                i18n           : widget.i18n.bind(widget),
                                base_templates : widget.baseTemplates,
                            })),
                        });
                    },
                });

            });
        };

        this.request = function (requestType, url, params = {}) {
            let responseForDebug = null;
            return new Promise(function (resolve, reject) {
                $[requestType](url, params)
                    .done(response => {
                        responseForDebug = response;
                        if (!('success' in response)) {
                            return resolve(response);
                        }

                        if (!response.success) {
                            return reject(response);
                        }

                        return resolve(response.data);
                    })
                    .fail(response => {
                        responseForDebug = response;

                        return reject(response);
                    })
                    .always(function () {
                        self.debug.log(`Выполнен запрос типа ${requestType} на url ${url} с параметрами:`, params);
                        self.debug.log('Ответ:', responseForDebug);
                    });
            });
        };

        this.get = function (url, params = {}) {
            return self.request('get', url, params);
        };

        this.getJson = function (url, params = {}) {
            return self.request('getJSON', url, params);
        };

        this.post = function (url, params = {}) {
            return self.request('post', url, params);
        };

        this.appendCss = function (fileName, isFullPath = false) {
            const fullPath = isFullPath ? fileName : widget.cssPath + fileName + '.css';

            if ($(`link[href="${fullPath}"]`).length) {
                return false;
            }

            $('head').append(`<link rel="stylesheet" href="${fullPath}" type="text/css"/>`);

            return true;
        };

        this.updateUserInfo = function () {
            return self.post(self.getUrl('widget', 'update'));
        };

        this.getSettings = function () {
            const area = AMOCRM.getV3WidgetsArea();
            let method = null;

            if (area === 'settings.widgets' || area === 'widget.advanced_settings') {
                method = 'get_advanced_settings';
            } else {
                method = 'get_right_widget_settings';
            }

            return self.post(self.getUrl('settings', method));
        };

        this.createModal = function (templateName = null, templateData = {}, options = {}) {
            return new Promise(function (resolve) {
                (templateName ? self.getTemplatePromise(templateName) : Promise.resolve()).then(template => {
                    let $modalBodyTemp = null;

                    const modal = new Modal({
                        default_overlay : options.default_overlay || false,
                        destroy() {
                            if (options.destroy) {
                                options.destroy();
                            }
                        },
                        init($modalBody) {
                            if (options.attr) {
                                $modalBody.attr(options.attr);
                            }

                            if (options.add_class) {
                                $modalBody.addClass(options.add_class);
                            }

                            if (options.id) {
                                $modalBody.attr('id', options.id);
                            }

                            if (options.css) {
                                $modalBody.css(options.css);
                            }

                            if (options.html) {
                                $modalBody.html(options.html);
                            }

                            if (template) {
                                templateData.base_templates = widget.baseTemplates;
                                $modalBody.html(template.render(templateData));
                            }

                            $modalBodyTemp = $modalBody;
                        },
                    });

                    resolve({$modalBody : $modalBodyTemp, modal});
                });
            });
        };
    };
});
