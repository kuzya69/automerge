<?php

class Widget extends \Helpers\Widgets
{
    const BASE_WIDGET8_URL = 'https://v2.widget8.ru/getdoc';

    protected function endpoint_digital_pipeline()
    {
        $this->sendRequest(
            '/dp/webhook',
            $_REQUEST
        );
    }

    private function sendRequest($endpoint, $data)
    {
        $link = self::BASE_WIDGET8_URL . $endpoint;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $result = curl_exec($ch);

        curl_close($ch);

        return $result;
    }
}
